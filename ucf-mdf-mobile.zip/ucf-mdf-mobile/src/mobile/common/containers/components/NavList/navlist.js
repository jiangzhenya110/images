// import React from 'react'
import { Mine, Workbench } from "../Icon";
const PREFIX = process.env.__CLIENT__ ? (window._baseUrl || '') : (process.env.PREFIX || '');
const CLIENT = process.env.__CLIENT__;
let DOMAIN_PREFIX = CLIENT ? (window._baseUrl || '') : (PREFIX || '');
if (DOMAIN_PREFIX === undefined) {
  DOMAIN_PREFIX = ""
}
// console.log(DOMAIN_PREFIX,'0000000000')
export const navlist = [
  {
    Icon: Workbench,
    title: '工作台',
    link:`${DOMAIN_PREFIX}/workbench/home/work`
  },
  {
    Icon: Mine,
    title: '我的',
    link:`${DOMAIN_PREFIX}/workbench/home/mine`
  },
];
