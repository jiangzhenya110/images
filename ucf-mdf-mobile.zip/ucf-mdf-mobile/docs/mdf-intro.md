'use strict';

module.exports = mdfApp;

function mdfApp() {
    // TODO
}
