import { LOGIN } from "../../actions/login";
import { TENANT_CHANGE, RESET } from '../../actions/appsAction'
// import { fromJS }  from 'immutable'
const defaultState = {
  userName: window.localStorage.getItem("userName") || "",
  tenantList: window.localStorage.getItem("tenantList")?JSON.parse(window.localStorage.getItem("tenantList")):[],
  userCode: "",
  userEmail: "",
  userId:window.localStorage.getItem("userId") ||  "",
  userMobile: [],
  tenantId: window.localStorage.getItem("tenantId") || "",
  access_token: window.localStorage.getItem("access_token") || '',
  tenantName:window.localStorage.getItem("tenantName") || ''
};
export default (state = defaultState, { type, payload }) => {
  switch (type) {
    case RESET:
      return {
        userName: "",
        tenantList: [],
        userCode: "",
        userEmail: "",
        userId: "",
        userMobile: [],
        tenantId: "",
        access_token: window.localStorage.getItem("access_token") || '',
        tenantName:window.localStorage.getItem("tenantName") || ''
      }
    case LOGIN:
      // console.log('payload',payload)
      return {
        ...state,
        ...payload,
      };
    case TENANT_CHANGE:
      return {
        ...state,
        ...payload,
      }
  }
  return state;
};
