import html from './html'

export default function viewhook () {
  return async function (ctx, next) {
    // console.log('%%%%%%%%%%%%%%%%%%')
    // console.log(ctx.request.url)
    // console.log('%%%%%%%%%%%%%%%%%%')
    ctx.render = function () {
      ctx.type = 'html';
      ctx.body = html(ctx.request.url.includes('/workbench'))
    }

    await next()
  }
}
