import { About } from "./About";
import { Bgcli } from "./Bgcli";
import { Change } from "./Change";
import { Editor } from "./Editor";
import { Mine } from "./Mine";
import { Show } from "./Show";
import { Space } from "./Space";
import { Set } from "./Set";
import { Triangle } from "./Triangle";
import { Workbench } from "./Workbench";

export { About, Bgcli, Change,Editor, Mine, Show, Space,Set, Triangle, Workbench };
