import React, { useState,useEffect } from "react";
// import mtl from "mtl-js-sdk";
import { Link,useHistory } from "react-router-dom";
import { connect } from 'react-redux'
import YInput from "../components/Input";
import { Change, Show, Triangle } from "../components/Icon";
import { Mine } from '../components/Icon'
import { loginFunc } from '../../actions/login'

import "./index.css";
const PREFIX = process.env.__CLIENT__ ? (window._baseUrl || '') : (process.env.PREFIX || '');
const CLIENT = process.env.__CLIENT__;
let DOMAIN_PREFIX = CLIENT ? (window._baseUrl || '') : (PREFIX || '');
if (DOMAIN_PREFIX === undefined) {
  DOMAIN_PREFIX = ""
}
// import Password from "antd/lib/input/Password";
const Login = ({ loginFunc, theUserName }) => {
  // console.log(window.localStorage.getItem('evnurl'))
  useEffect(() => {
    if (!window.localStorage.getItem('evnurl')) {
      history.replace(`${DOMAIN_PREFIX}/workbench/config/config`)
    }
    window.document.body.style.height =
      window.innerHeight + 'px';
    return () => {
      window.document.body.removeAttribute("style")
    }
  },[])

  const history = useHistory()
  const [isTel, setIsTel] = useState(true);
  const [isShow, setIsShow] = useState(false);
  const [userName, setUserName] = useState("");
  const [pwd, setPwd] = useState("");
  const userNameHanle = (e) => {
    // console.log(e.target.value)
    setUserName(e.target.value);
  };
  const pwdHanle = (e) => {
    // console.log(e.target.value)
    setPwd(e.target.value);
  };
  // const { loginVal } = useParams()
  const userNameChange = () => {
    setIsTel(!isTel);
    setUserName("");
  };
  const showChang = () => {
    setIsShow(!isShow);
  };
  const loginHandle = () => {
    loginFunc({username: userName,password: pwd},history)
  };
  return (
    <div className={"box"}  id={'yo-box'}>
      <div className={"head-img"}>
        {/* <img src="" alt="" /> */}
        <Mine ></Mine>
      </div>
      <div className={"pt30"}>欢迎 {theUserName || window.localStorage.getItem('userName')}</div>
      <div className="form">
        <div className={"line"}>
          {isTel ? (
            <div className={"fir"}>
              <span>+86 </span>
              <span className={"tri"}>
                <Triangle></Triangle>
              </span>
            </div>
          ) : null}
          <YInput
            className={`${isTel ? "mid-input" : "long-input"}`}
            type={'text'}
            label={isTel ? "手机号" : "邮箱"}
            value={userName}
            onChange={userNameHanle}
          />
          {/* <div> */}
          <Change onClick={userNameChange}></Change>
          {/* <img src={ Change } alt=""/> */}
          {/* </div> */}
        </div>
        <div className={"line"}>
          <YInput
            className={"long-input"}
            type={isShow ? "text" : "password"}
            label={"密码"}
            value={pwd}
            onChange={pwdHanle}
          ></YInput>
          <Show isShow={isShow} onClick={showChang}></Show>
        </div>
      </div>
      <div className="log-con">
        <button className={"log-button"} onClick={loginHandle}>
          登录
        </button>
      </div>
      <div className={"login-change"}>
        {/* <Link className={"yo-link"} to={"/logincode"}> */}
        {/* <Link className={"yo-link"} to={"/"}>
          验证码登录
        </Link> */}
      </div>
    </div>
  );
};

export default connect(state => {
  // console.log('90909090',state)
  return ({
    theUserName:state.loginMessage.userName
  })
}, {
  loginFunc:loginFunc
})(Login);
