export const ADD_BAR_CODE = 'ADD_BAR_CODE';
export const DELETE_BAR_CODE = 'DELETE_BAR_CODE';
export const MODIFY_BAR_CODE = 'MODIFY_BAR_CODE';
