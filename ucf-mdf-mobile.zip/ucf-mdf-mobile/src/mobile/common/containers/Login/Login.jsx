import React, { useState, useEffect } from "react";
import YInput from "../../components/Input";
import { Link } from "react-router-dom";
// import Change from "../../static/imgs/change.svg";
import { Change, Triangle } from "../../components/Icon";
import { LeftOutlined } from "@ant-design/icons";

// import
import "./index.css";
// import Password from "antd/lib/input/Password";
const LoginCode = () => {
  const [isTel, setIsTel] = useState(true);
  const [isClick, setIsClick] = useState(false);
  const [btnVal, setBtnVal] = useState("获取验证码");
  // const { loginVal } = useParams()
  const userNameChange = () => {
    setIsTel(!isTel);
  };
  // const showChang = () => {
  //   setIsShow(!isShow);
  // };
  let interval = 0;
  const getCode = () => {
    if (isClick) return;
    setIsClick(true);
    let i = 10;
    setBtnVal(i);
    interval = setInterval(() => {
      i--;
      setBtnVal(i);
      if (i === 0) {
        setIsClick(false);
        setBtnVal("获取验证码");
        clearInterval(interval);
      }
    }, 1000);
  };
  useEffect(() => {
    return () => {
      clearInterval(interval);
    };
  }, []);
  return (
    <div className={"box"}>
      <div>
        <Link className={"yo-link"} to={"/login"} replace>
          <LeftOutlined className={"arrow-left"} />
        </Link>
      </div>
      <div className={"pt108"}>验证码登录</div>
      <div className="form">
        <div className={"line"}>
          {isTel ? (
            <div className={"fir"}>
              <span>+86 </span>
              <span className={"tri"}>
                <Triangle></Triangle>
              </span>
            </div>
          ) : null}
          <YInput
            className={`${isTel ? "mid-input" : "long-input"}`}
            type={isTel ? "tel" : "email"}
            label={isTel ? "手机号" : "邮箱"}
          />
          {/* <div> */}
          <Change onClick={userNameChange}></Change>
          {/* <img src={ Change } alt=""/> */}
          {/* </div> */}
        </div>
        <div className={"line"}>
          <YInput
            className={"shot-input"}
            // type={isShow ? "text" : "password"}
            type={"text"}
            label={"验证码"}
          ></YInput>
          {/* <Show isShow={isShow} onClick={showChang}></Show> */}
          <button className={"get-code"}>
            <span onClick={getCode}>{btnVal}</span>
          </button>
        </div>
      </div>
      <div className="log-con-next">
        <button className={"log-button"}>下一步</button>
      </div>
      {/* <div className={"login-change"}>
        <span>验证码登录</span>
      </div> */}
    </div>
  );
};

export default LoginCode;
