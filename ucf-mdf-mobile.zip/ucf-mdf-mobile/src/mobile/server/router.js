import Router from "koa-router";
import use from "@mdf/plugin-meta/lib/router";
import preview from "./controllers/preview";

const router = Router();
if (process.env.PREFIX === undefined) {
  process.env.PREFIX = "";
}
process.env.PREFIX && router.prefix(process.env.PREFIX);
use(router);

router.get("/view/:billtype/:billno", function (ctx) {
  ctx.render();
});

router.post("/server/hash", async function (ctx) {
    await preview.hash(ctx);
});

router.get("/server/preview",async function (ctx) {
    await preview.render(ctx);
});
router.get("/workbench/home/work", function (ctx) {
  ctx.render();
});
router.get("/workbench", function (ctx) {
  ctx.render();
});
router.get("/workbench/login", function (ctx) {
  ctx.render();
});
router.get("/workbench/home/mine", function (ctx) {
  ctx.render();
});
router.get("/workbench/config", function (ctx) {
  ctx.render();
});
router.get("/workbench/config/:config", function (ctx) {
  ctx.render();
});


export default router;
