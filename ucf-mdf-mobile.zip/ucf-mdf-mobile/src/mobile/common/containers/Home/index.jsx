import React, { useEffect,useState } from "react";
import { NavList } from "../components/NavList";
import { useHistory, Switch, Route } from "react-router-dom";
// import { DOMAIN_PREFIX } from '../../route'
import "./index.css";
import Work from "../Work";
import Mine from "../Mine";
const PREFIX = process.env.__CLIENT__ ? (window._baseUrl || '') : (process.env.PREFIX || '');
const CLIENT = process.env.__CLIENT__;
let DOMAIN_PREFIX = CLIENT ? (window._baseUrl || '') : (PREFIX || '');
if (DOMAIN_PREFIX === undefined) {
  DOMAIN_PREFIX = ""
}
const Index = (props) => {
  const history = useHistory();
  // console.log('===========',history.location.pathname,history.location.pathname === `${DOMAIN_PREFIX}/workbench/home/mine`)
  const [clickIndex, setClickIndex] = useState(history.location.pathname === `${DOMAIN_PREFIX}/workbench/home/mine`? 1 : 0)
  // useEffect(() => {
    // console.log(1111)
    // history.replace(`${DOMAIN_PREFIX}/workbench/home/work`);
  // });
  // console.log(history,clickIndex)
  return (
    <div className={"yo-home"}>
      <div className="yo-index">
        <Switch>
          <Route path={`${DOMAIN_PREFIX}/workbench/home/work`} component={Work} />
          <Route path={`${DOMAIN_PREFIX}/workbench/home/mine`} component={Mine} />
        </Switch>
      </div>
      <NavList clickIndex={clickIndex} setClickIndex={setClickIndex}></NavList>
    </div>
  );
};

export default Index;
