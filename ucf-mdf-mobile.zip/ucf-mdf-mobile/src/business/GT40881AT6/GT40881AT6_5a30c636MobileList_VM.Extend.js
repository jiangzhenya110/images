/**
 * 证明开具移动端列表页面
 * 刘董
 * 2020年10月22日
 */

cb.define([], function (common) {
    debugger;
    var GT40881AT6_5a30c636MobileList_VM_Extend = {
      doAction: function (name, viewmodel) {
        if (this[name])
          this[name](viewmodel);
      },
      init: function (viewmodel) {

        viewmodel.get('1603284891847_2').on('click',function(){
             //封装接口参数，没有就不写
             debugger;
            var params = {
            };
            //调用后端查询待办任务接口请求路径
            debugger;
            var url = '/snhmProveLssue/completedTask?terminalType=3';
            var proxy = cb.rest.DynamicProxy.create({
            settle: {
                url: url,
                //请求方法，根据自己写的后端接口方法写
                method: "GET"
            }
            });
            proxy.settle(params,function(err,result){
            if(err){
                cb.utils.alert(err.message,'error');
                return;
            }
            //固定写法，将后端返回的数据结果result展示在列表界面
            viewModel.getGridModel().setState('dataSourceMode', 'local');
            viewModel.getGridModel().setDataSource(result);
            viewModel.getGridModel().setState('dataSourceMode', 'remote');
            });
        })


       common.print(viewmodel);
      }
    }
    try {
      module.exports = GT40881AT6_5a30c636MobileList_VM_Extend;
    } catch (error) {
  
    }
    return GT40881AT6_5a30c636MobileList_VM_Extend;
  });