
require('@mdf/theme/theme-ncc/default/minxin-themeColors.less')
require('@mdf/theme/theme-ncc/index.less')

require('./default/upc-common.less')
