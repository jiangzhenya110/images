import mtl from "mtl-js-sdk";
import { Toast } from 'antd-mobile'
// import {mtlLoginByPassword} from './utils'
// import appCenter from "mtl-js-sdk/lib/plugins/appcenter";
// mtl.loadPlugin(appCenter);
// import notice from 'mtl-js-sdk/lib/plugins/notice'
import notice from 'mtl-js-sdk/lib/plugins/notice'
mtl.loadPlugin(notice);


//正式环境
// const appMsg = {
//   appKey: "b9bda123894a4fcfb9ab7153122a4b19",
//   appSecret: "42d2873655034a22964bb0f4ded443a9",
// };
// 测试环境
// const appMsg = {appKey: '8218b8f2df9d483aa1f773a67213541d',
// appSecret: 'fe16655e8ed947dfa15159dece97ba16',}

export const LOGIN = "LOGIN";
const PREFIX = process.env.__CLIENT__
  ? window._baseUrl || ""
  : process.env.PREFIX || "";
const CLIENT = process.env.__CLIENT__;
let DOMAIN_PREFIX = CLIENT ? window._baseUrl || "" : PREFIX || "";
if (DOMAIN_PREFIX === undefined) {
  DOMAIN_PREFIX = "";
}

const loginAction = (payload) => ({
  type: LOGIN,
  payload,
});

export const loginFunc = (data, action) => (dispatch) => {
  /*
  userMobile,
          userName,
  */
  mtl.login({
    ...data,
    url: window.localStorage.getItem('evnurl'),
    success: (res) => {
        let tenantId = "",tenantName='',tenantList=[];
      const { data: { userInfo, tenants, yhtToken,sessionInfo } } = res

        window.localStorage.setItem("userName", userInfo.userName);
        window.localStorage.setItem("userId", userInfo.userId);
        window.localStorage.setItem("tenantList", JSON.stringify(tenants));
        window.localStorage.setItem("wb_at", JSON.stringify(sessionInfo.sessionId));
        window.localStorage.setItem("yhtToken", yhtToken.yhtAccessToken);
      Toast.success(`登录成功！`, 1);
      console.log('sdfasdfasdf',action)
      action.replace(`${DOMAIN_PREFIX}/workbench/home/work`);
      if (
        window.localStorage.getItem("tenantId") &&
        tenantList.some((item) => {
          return (
            item.tenant.tenantId === window.localStorage.getItem("tenantId")
          );
        })
      ) {
        tenantId = window.localStorage.getItem("tenantId");
        tenantName = window.localStorage.getItem("tenantName");
        // tenantName = tenantList.filter(item => {
        //   return tenantId === item.tenant.tenantId
        // }).tenant.tenantName;
      } else if (tenants[0]) {
        tenantId = tenants[0].tenantId;
        tenantName=tenants[0].tenantName
        window.localStorage.setItem("tenantId", tenantId);
        window.localStorage.setItem("tenantName", tenantName);
      } else {
        tenantId = "";
        window.localStorage.setItem("tenantId", "");
      }
      dispatch(
        loginAction({
          tenantList:tenants,
          userCode:userInfo.userCode,
          userEmail:userInfo.userEmail,
          userId:userInfo.userId,
          userMobile:userInfo.userMobile,
          userName:userInfo.userName,
          tenantId,
          // access_token,
          tenantName
        }))

      if (mtl.platform.toLowerCase() === "qyandroid") {
        mtl.notice.init({
          apihost: 'https://ezone-u8c-daily.yyuap.com',
          login_url: 'https://build.yyuap.com',
          im_server: 'u8cim-daily.yyuap.com',
          im_short_server: 'u8cim-daily.yyuap.com',
          im_short_port: 5222,
          im_short_scheme: 'https',
          loginInfo:res.data,
          success: function(res){
            // alert('初始化成功')
            // console.log('notictInitSuccess',res)
          },
          fail: function(err){
            // console.log('notictInitError',err)
          }
        })

      }

    },
    fail: function (err) {
        Toast.fail(err.message || "登录失败", 1);
    }
})
}
