export InputQrcode from './InputQrcode';
export radioColor from './radioColor';
// export DynamicView from './DynamicView';
