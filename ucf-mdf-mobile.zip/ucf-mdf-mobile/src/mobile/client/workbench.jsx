import React, { useEffect } from "react";
import ReactDom from "react-dom";
import Router from "../common/route/workRoute";
import { Provider } from "react-redux";
import { configureStore } from "../common/store";
import "./client.css";
const store = configureStore();
const App = () => {
  useEffect(() => {
    window.document.getElementById("container").style.height =
      window.innerHeight + "px";
    return () => {
      window.document.getElementById("container").removeAttribute("style");
    };
  }, []);
  return (
    <Provider store={store}>
      <Router />
    </Provider>
  );
};

ReactDom.render(<App />, document.getElementById("container"));

// if (module.hot) {
//   module.hot.accept();
// }
