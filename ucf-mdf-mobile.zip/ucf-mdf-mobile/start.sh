pm2 start --name fe-client  npm -- run debug:mobile:client
pm2 start --name fe-server  npm -- run debug:mobile:server
