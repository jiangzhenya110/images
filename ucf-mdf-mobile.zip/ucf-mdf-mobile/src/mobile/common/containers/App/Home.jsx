import * as React from 'react'

import {MenuContainer} from '../Menu'

export default class Home extends React.Component {
  render () {
    return <div>
      <MenuContainer />
    </div>
  }
}
