// 控件交互的配置问题，例如所有表格显示行号，规范是不显示行号的
export default {
  table: {
    showRowNo: true // 显示表格行号
  }
}
