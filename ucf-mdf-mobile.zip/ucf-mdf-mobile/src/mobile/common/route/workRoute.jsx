import React from "react";
import { Route, BrowserRouter, Switch } from "react-router-dom";
import Confs from '../containers/Confs'
import Login from "../containers/Login";
import LoginCode from "../containers/Login/Login";
import Index from "../containers/Home";
const PREFIX = process.env.__CLIENT__
  ? window._baseUrl || ""
  : process.env.PREFIX || "";
const CLIENT = process.env.__CLIENT__;
let DOMAIN_PREFIX = CLIENT ? window._baseUrl || "" : PREFIX || "";
if (DOMAIN_PREFIX === undefined) {
  DOMAIN_PREFIX = "";
}
window.DOMAIN_PREFIX = DOMAIN_PREFIX;
const Router = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route path={`${DOMAIN_PREFIX}/workbench/login`} component={Login} />
        <Route path={`${DOMAIN_PREFIX}/workbench/config/:id`} component={Confs} />
        <Route path={`${DOMAIN_PREFIX}/workbench/config`} component={Confs} />
        <Route
          path={`${DOMAIN_PREFIX}/workbench/logincode`}
          component={LoginCode}
        />
        <Route path={`${DOMAIN_PREFIX}/workbench/home`} component={Index} />
      </Switch>
    </BrowserRouter>
  );
};
export default Router
