// ncc 配置
import  ConfigComp from '@mdf/metaui-web-ncc/lib/components/config.comp';
let extendConfig = Object.assign({iconfont:true},ConfigComp);


// ys 默认配置
// let extendConfig = {};


export default extendConfig;
