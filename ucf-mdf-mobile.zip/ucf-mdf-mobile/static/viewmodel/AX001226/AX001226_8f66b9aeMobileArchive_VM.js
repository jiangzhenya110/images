//yyarchive

console.info('%c AX001226_8f66b9aeMobileArchive_VM js init', 'color:green');
cb.viewmodels.register('AX001226_8f66b9aeMobileArchive_VM', function(modelType) {

    var model = function(data) {
        cb.models.ContainerModel.call(this, data);
        this.init();
    };
    model.prototype = cb.utils.getPrototype(cb.models.ContainerModel.prototype);
    model.prototype.modelType = modelType;

    model.prototype.init = function() {
        var _this = this;
        var fields = {


            'parent': new cb.models.SimpleModel({
                "cFieldName": "parent",
                "cItemName": "parent",
                "cCaption": "父实体",
                "cShowCaption": "父实体",
                "iBillEntityId": 4281,
                "iBillTplGroupId": 13561,
                "iTplId": 3454,
                "iMaxLength": 200,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bExtend": false,
                "bCanModify": true,
                "iColWidth": 1,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bSelfDefine": false,
                "cTplGroupName": "DIV块",
                "bMain": true,
                "cDataSourceName": "AX001226.AX001226.lh_0319042",
                "cControlType": "input",
                "bVmExclude": 0,
                "iOrder": 0,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "bEnableFormat": false
            }),


            'code': new cb.models.SimpleModel({
                "cFieldName": "code",
                "cItemName": "code",
                "cCaption": "编码",
                "cShowCaption": "编码",
                "iBillEntityId": 4281,
                "iBillTplGroupId": 13561,
                "iTplId": 3454,
                "iMaxLength": 200,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bExtend": false,
                "bCanModify": true,
                "iColWidth": 1,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bSelfDefine": false,
                "cTplGroupName": "DIV块",
                "bMain": true,
                "cDataSourceName": "AX001226.AX001226.lh_0319042",
                "cControlType": "input",
                "bVmExclude": 0,
                "iOrder": 10,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "bEnableFormat": false
            }),


            'level': new cb.models.SimpleModel({
                "cFieldName": "level",
                "cItemName": "level",
                "cCaption": "难度",
                "cShowCaption": "难度",
                "iBillEntityId": 4281,
                "iBillTplGroupId": 13561,
                "iTplId": 3454,
                "iMaxLength": 11,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bExtend": false,
                "iNumPoint": 2,
                "bCanModify": true,
                "iColWidth": 1,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bSelfDefine": false,
                "cTplGroupName": "DIV块",
                "bMain": true,
                "cDataSourceName": "AX001226.AX001226.lh_0319042",
                "cControlType": "inputnumber",
                "bVmExclude": 0,
                "iOrder": 20,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "bEnableFormat": false
            }),


            'enable': new cb.models.SimpleModel({
                "cFieldName": "enable",
                "cItemName": "enable",
                "cCaption": "启用",
                "cShowCaption": "启用",
                "iBillEntityId": 4281,
                "iBillTplGroupId": 13561,
                "iTplId": 3454,
                "iMaxLength": 5,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bExtend": false,
                "bCanModify": true,
                "iColWidth": 1,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bSelfDefine": false,
                "cTplGroupName": "DIV块",
                "bMain": true,
                "cDataSourceName": "AX001226.AX001226.lh_0319042",
                "cControlType": "switch",
                "bVmExclude": 0,
                "iOrder": 30,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "bEnableFormat": false
            }),


            'name': new cb.models.SimpleModel({
                "cFieldName": "name",
                "cItemName": "name",
                "cCaption": "名称",
                "cShowCaption": "名称",
                "iBillEntityId": 4281,
                "iBillTplGroupId": 13561,
                "iTplId": 3454,
                "iMaxLength": 200,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bExtend": false,
                "bCanModify": true,
                "iColWidth": 1,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bSelfDefine": false,
                "cTplGroupName": "DIV块",
                "bMain": true,
                "cDataSourceName": "AX001226.AX001226.lh_0319042",
                "cControlType": "input",
                "bVmExclude": 0,
                "iOrder": 40,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "bEnableFormat": false
            }),


            'describe': new cb.models.SimpleModel({
                "cFieldName": "describe",
                "cItemName": "describe",
                "cCaption": "描述信息",
                "cShowCaption": "描述信息",
                "iBillEntityId": 4281,
                "iBillTplGroupId": 13561,
                "iTplId": 3454,
                "iMaxLength": 255,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bExtend": false,
                "bCanModify": true,
                "iColWidth": 1,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bSelfDefine": false,
                "cTplGroupName": "DIV块",
                "bMain": true,
                "cDataSourceName": "AX001226.AX001226.lh_0319042",
                "cControlType": "textarea",
                "bVmExclude": 0,
                "iOrder": 50,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "bEnableFormat": false
            }),


            'id': new cb.models.SimpleModel({
                "cFieldName": "id",
                "cItemName": "id",
                "cCaption": "ID",
                "cShowCaption": "ID",
                "iBillEntityId": 4281,
                "iBillTplGroupId": 13561,
                "iTplId": 3454,
                "iMaxLength": 36,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": true,
                "bExtend": false,
                "bCanModify": true,
                "iColWidth": 1,
                "bShowIt": false,
                "bFilter": true,
                "bIsNull": true,
                "bSelfDefine": false,
                "cTplGroupName": "DIV块",
                "bMain": true,
                "cDataSourceName": "AX001226.AX001226.lh_0319042",
                "cControlType": "input",
                "bVmExclude": 0,
                "iOrder": 60,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "bEnableFormat": false
            }),


            'pubts': new cb.models.SimpleModel({
                "cFieldName": "pubts",
                "cItemName": "pubts",
                "cCaption": "时间戳",
                "cShowCaption": "时间戳",
                "iBillEntityId": 4281,
                "iBillTplGroupId": 13561,
                "iTplId": 3454,
                "iMaxLength": 255,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": true,
                "bExtend": false,
                "bCanModify": true,
                "iColWidth": 1,
                "bShowIt": false,
                "bFilter": true,
                "bIsNull": true,
                "bSelfDefine": false,
                "cTplGroupName": "DIV块",
                "bMain": true,
                "cDataSourceName": "AX001226.AX001226.lh_0319042",
                "cControlType": "datepicker",
                "bVmExclude": 0,
                "iOrder": 70,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "bEnableFormat": false
            }),


            'btnSave': new cb.models.SimpleModel({
                "cItemName": "btnSave",
                "cCaption": "保存",
                "cShowCaption": "保存",
                "bEnum": false,
                "cControlType": "primarybutton",
                "iStyle": 0,
                "cCommand": "cmdSave",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "55115",
                "needClear": false,
                "value": "保存"
            }),


            'btnSaveAndAdd': new cb.models.SimpleModel({
                "cItemName": "btnSaveAndAdd",
                "cCaption": "保存并新增",
                "cShowCaption": "保存并新增",
                "bEnum": false,
                "cControlType": "primarybutton",
                "iStyle": 0,
                "cCommand": "cmdSaveAndAdd",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "55113",
                "needClear": false,
                "value": "保存并新增"
            }),


            'scan': new cb.models.SimpleModel({
                "cItemName": "scan",
                "cCaption": "取消",
                "cShowCaption": "取消",
                "bEnum": false,
                "cControlType": "button",
                "iStyle": 0,
                "cCommand": "cmdAbandon",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "55114",
                "needClear": false
            }),


            'params': {
                "billType": "YYArchive",
                "primaryKey": "id",
                "masterOrgField": null
            },


            'depends': {},

        };
        this.setData(fields);
        this.setDirty(false);



        var billType = "yyarchive" || 'voucher';
        var biz;
        if (billType == 'option' || billType == 'freeview') {
            biz = cb.biz.common[billType];
        } else {
            biz = cb.biz.common.voucher;
        }


        //common events start
        //actions

        _this.allActions = [{
            "cCommand": "btnSaveAndAdd",
            "cAction": "saveandadd",
            "cSvcUrl": "/bill/save",
            "cHttpMethod": "POST",
            "cParameter": "{\"isWeb\":\"false\"}"
        }, {
            "cCommand": "btnSave",
            "cAction": "save",
            "cSvcUrl": "/bill/save",
            "cHttpMethod": "POST",
            "cParameter": "{\"isWeb\":\"false\"}"
        }, {
            "cCommand": "btnAbandon",
            "cAction": "newback"
        }, {
            "cCommand": "scan",
            "cAction": "scan"
        }, {
            "cCommand": "back",
            "cAction": "newback"
        }, {
            "cCommand": "btnAdd",
            "cAction": "newadd"
        }];




        _this.get('btnSaveAndAdd').on('click', function(params) {
            var args = cb.utils.extend(true, {}, {
                "cmdParameter": "{\"isWeb\":\"false\"}",
                "cCommand": "cmdSaveAndAdd",
                "cAction": "saveandadd",
                "cSvcUrl": "/bill/save",
                "cHttpMethod": "POST",
                "cParameter": "{\"isWeb\":\"false\"}",
                "cItemName": "btnSaveAndAdd",
                "cCaption": "保存并新增",
                "cShowCaption": "保存并新增",
                "bEnum": false,
                "cControlType": "primarybutton",
                "iStyle": 0,
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "55113",
                "needClear": false,
                "value": "保存并新增"
            }, {
                key: 'btnSaveAndAdd'
            }, {
                params: params
            });
            args.cShowCaption = this._get_data('cShowCaption');
            args.cCaption = this._get_data('cCaption');

            var self = this;
            args.disabledCallback = function() {
                self.setDisabled(true);
            }
            args.enabledCallback = function() {
                self.setDisabled(false);
            }

            biz.do('saveandadd', _this, args)
        });


        _this.get('btnSave').on('click', function(params) {
            var args = cb.utils.extend(true, {}, {
                "cmdParameter": "{\"isWeb\":\"false\"}",
                "cCommand": "cmdSave",
                "cAction": "save",
                "cSvcUrl": "/bill/save",
                "cHttpMethod": "POST",
                "cParameter": "{\"isWeb\":\"false\"}",
                "cItemName": "btnSave",
                "cCaption": "保存",
                "cShowCaption": "保存",
                "bEnum": false,
                "cControlType": "primarybutton",
                "iStyle": 0,
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "55115",
                "needClear": false,
                "value": "保存"
            }, {
                key: 'btnSave'
            }, {
                params: params
            });
            args.cShowCaption = this._get_data('cShowCaption');
            args.cCaption = this._get_data('cCaption');

            var self = this;
            args.disabledCallback = function() {
                self.setDisabled(true);
            }
            args.enabledCallback = function() {
                self.setDisabled(false);
            }

            biz.do('save', _this, args)
        });


        _this.get('scan').on('click', function(params) {
            var args = cb.utils.extend(true, {}, {
                "cCommand": "cmdAbandon",
                "cAction": "scan",
                "cItemName": "scan",
                "cCaption": "取消",
                "cShowCaption": "取消",
                "bEnum": false,
                "cControlType": "button",
                "iStyle": 0,
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "55114",
                "needClear": false
            }, {
                key: 'scan'
            }, {
                params: params
            });
            args.cShowCaption = this._get_data('cShowCaption');
            args.cCaption = this._get_data('cCaption');

            biz.do('scan', _this, args)
        });



        //check



        _this.on('columnSetting', function(params) {
            biz.do('columnSetting', _this, params);
        });
        //common events end


        var girdModelKeys = []
        if (girdModelKeys) {
            girdModelKeys.forEach(function(key) {
                var gridModel = _this.get(key);
                if (gridModel) {
                    gridModel.on('afterCellValueChange', function(params) {
                        if (params) params.childrenField = key;
                        biz.do('cellCheck', _this, params);
                    })
                }
            })
        }
        //注册
        _this.on('filterClick', function(params) {
            biz.do('search', _this, params);
        });



        this.biz = biz;
        // this.initData();
    };
    model.prototype.initData = function() {
        // if(cb.biz['AX001226'] && cb.biz['AX001226']['AX001226_8f66b9aeMobileArchive_VM_Extend']){
        //   console.info('%c AX001226_8f66b9aeMobileArchive_VM_Extend extendjs doAction', 'color:green');
        //   cb.biz['AX001226']['AX001226_8f66b9aeMobileArchive_VM_Extend'].doAction("init", this);
        // }else{
        //   console.log('%c no extend js' , 'font-size:22pt;color:red');
        // }
        var self = this;
        var extendFile = 'AX001226/AX001226_8f66b9aeMobileArchive_VM.Extend.js';
        cb.require([extendFile], function(extend) {
            if (extend && extend.doAction) {
                console.info('%c AX001226_8f66b9aeMobileArchive_VM_Extend extendjs doAction', 'color:green');
                // 处理扩展脚本异常导致渲染失败 yueming
                try {
                    extend.doAction("init", self);
                } catch (error) {
                    console.error('Exception in business script, please check');
                    console.error(error);
                }
            } else {
                console.error('%c 语法错误  ' + extendFile, 'font-size:12pt;color:#860786');
                console.error('%c extendVmName-->AX001226_8f66b9aeMobileArchive_VM_Extend', 'font-size:12pt;color:#860786')
            }
            self.execute('extendReady', self);
        }, function(error) {
            console.info('%c 未找到  ' + extendFile, 'font-size:12pt;color:#860786');
            console.info('%c extendVmName-->AX001226_8f66b9aeMobileArchive_VM_Extend', 'font-size:12pt;color:#860786')
            self.execute('extendReady', self);
        });
    };

    return model;
});