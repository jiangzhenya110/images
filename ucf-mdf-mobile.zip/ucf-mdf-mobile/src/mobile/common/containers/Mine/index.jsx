import React, { Fragment, useEffect, useState } from "react";
import { Editor, Space, Set, About } from "../components/Icon";
import { RightOutlined } from "@ant-design/icons";
import Toast from "antd-mobile/lib/toast";
import "antd-mobile/lib/toast/style";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import "./index.css";
import mtl from "mtl-js-sdk";
import notice from 'mtl-js-sdk/lib/plugins/notice'
mtl.loadPlugin(notice);

const PREFIX = process.env.__CLIENT__
  ? window._baseUrl || ""
  : process.env.PREFIX || "";
const CLIENT = process.env.__CLIENT__;
let DOMAIN_PREFIX = CLIENT ? window._baseUrl || "" : PREFIX || "";
if (DOMAIN_PREFIX === undefined) {
  DOMAIN_PREFIX = "";
}

const Mine = ({ total, userName }) => {
  const [platformF, setPlatformF] = useState(false);
  useEffect(() => {
    const platform = mtl.platform.toLowerCase();
    if ( platform === "qyandroid") {
      setPlatformF(true);
    }
  }, []);
  const handleClick = () => {
    mtl.notice.openTodoList({
      success: function(res) {
        // let data = res;
      },
      fail: function(err) {
        var message = err.message; // 错误信息
        Toast.info(message, 2);
      }
    });
  };
  const handleClicklist = () => {
    mtl.notice.openNoticeList({
      success: function(res) {
        // let data = res;
      },
      fail: function(err) {
        var message = err.message; // 错误信息
        Toast.info(message, 2);
      }
    });
  };
  return (
    <div className="mine-box">
      <div className="mine-msg">
        <div className="mine-header"></div>
        <div>
          <p className="mine-name">
            <span>{userName}</span>
            <div className="mine-ed">
              <Editor></Editor>
            </div>
          </p>
          <p className="mine-des">应用开发</p>
        </div>
      </div>
      <div className="mine-app-num">
        <div className="mine-a-n">
          <p className="mine-num">21</p>
          <p className="mine-w">新发布应用</p>
        </div>
        <div className="mine-a-n">
          <p className="mine-num">{total}</p>
          <p className="mine-w">应用数量</p>
        </div>
      </div>
      <ul className="mine-list">
        <li className="mine-list-c">
          <div className="mine-c-l">
            <Space></Space>
          </div>
          <div className="mine-c-r">
            <span>应用数量</span>
            <RightOutlined className="mine-ar" />
          </div>
        </li>
        <Link
          style={{ color: "inherit" }}
          to={`${DOMAIN_PREFIX}/workbench/config`}
        >
          <li className="mine-list-c">
            <div className="mine-c-l">
              <Set></Set>
            </div>
            <div className="mine-c-r mine-c-r-l">
              <span>配置环境</span>
              <RightOutlined className="mine-ar" />
            </div>
          </li>
        </Link>
        {platformF ? (
          <Fragment>
            {/* <li className="mine-list-c" onClick={handleClick}>
              <div className="mine-c-l">
                <Set></Set>
              </div>
              <div className="mine-c-r mine-c-r-l">
                <span>待办通知</span>
                <RightOutlined className="mine-ar" />
              </div>
            </li> */}
            <li className="mine-list-c" onClick={handleClick}>
              <div className="mine-c-l">
                <Set></Set>
              </div>
              <div className="mine-c-r mine-c-r-l">
                <span>代办通知</span>
                <RightOutlined className="mine-ar" />
              </div>
            </li>
            <li className="mine-list-c" onClick={handleClicklist}>
              <div className="mine-c-l">
                <Set></Set>
              </div>
              <div className="mine-c-r mine-c-r-l">
                <span>通知列表</span>
                <RightOutlined className="mine-ar" />
              </div>
            </li>
          </Fragment>
        ) : (
          ""
        )}
      </ul>
      <ul className="mine-list">
        <li className="mine-list-c">
          <div className="mine-c-l">
            <About></About>
          </div>
          <div className="mine-c-r  mine-c-r-l">
            <span>关于</span>
            <RightOutlined className="mine-ar" />
          </div>
        </li>
      </ul>
    </div>
  );
};

export default connect((state) => {
  return {
    total: state.appsMessage.total,
    userName: state.loginMessage.userName,
  };
}, null)(Mine);
