//voucherlist

console.info('%c AX001226_8f66b9aeMobileList_VM js init', 'color:green');
cb.viewmodels.register('AX001226_8f66b9aeMobileList_VM', function(modelType) {

    var model = function(data) {
        cb.models.ContainerModel.call(this, data);
        this.init();
    };
    model.prototype = cb.utils.getPrototype(cb.models.ContainerModel.prototype);
    model.prototype.modelType = modelType;

    model.prototype.init = function() {
        var _this = this;
        var fields = {


            'btnAdd': new cb.models.SimpleModel({
                "cItemName": "btnAdd",
                "cCaption": "新建",
                "cShowCaption": "新建",
                "bEnum": false,
                "cControlType": "primarybutton",
                "iStyle": 0,
                "cCommand": "cmdAdd",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "50983",
                "needClear": false
            }),


            'ax001226_ax001226_lh_0319042_15846325299171': new cb.models.GridModel({
                "columns": {
                    "parent": {
                        "cFieldName": "parent",
                        "cItemName": "parent",
                        "cCaption": "父实体",
                        "cShowCaption": "父实体",
                        "iBillEntityId": 3940,
                        "iBillTplGroupId": 12353,
                        "iTplId": 3153,
                        "iMaxLength": 200,
                        "iFieldType": 1,
                        "bEnum": false,
                        "bMustSelect": true,
                        "bHidden": false,
                        "bExtend": false,
                        "bCanModify": true,
                        "iColWidth": 1,
                        "bShowIt": true,
                        "bFilter": true,
                        "bIsNull": true,
                        "bSelfDefine": false,
                        "cTplGroupName": "卡片",
                        "bMain": true,
                        "cDataSourceName": "AX001226.AX001226.lh_0319042",
                        "cControlType": "input",
                        "bVmExclude": 0,
                        "iOrder": 0,
                        "isshoprelated": false,
                        "iSystem": 1,
                        "authLevel": 3,
                        "isExport": true,
                        "uncopyable": false,
                        "bEnableFormat": false
                    },
                    "code": {
                        "cFieldName": "code",
                        "cItemName": "code",
                        "cCaption": "编码",
                        "cShowCaption": "编码",
                        "iBillEntityId": 3940,
                        "iBillTplGroupId": 12353,
                        "iTplId": 3153,
                        "iMaxLength": 200,
                        "iFieldType": 1,
                        "bEnum": false,
                        "bMustSelect": true,
                        "bHidden": false,
                        "bExtend": false,
                        "bCanModify": true,
                        "iColWidth": 1,
                        "bShowIt": true,
                        "bFilter": true,
                        "bIsNull": true,
                        "bSelfDefine": false,
                        "cTplGroupName": "卡片",
                        "bMain": true,
                        "cDataSourceName": "AX001226.AX001226.lh_0319042",
                        "cControlType": "input",
                        "bVmExclude": 0,
                        "iOrder": 10,
                        "isshoprelated": false,
                        "iSystem": 1,
                        "authLevel": 3,
                        "isExport": true,
                        "uncopyable": false,
                        "bEnableFormat": false
                    },
                    "level": {
                        "cFieldName": "level",
                        "cItemName": "level",
                        "cCaption": "难度",
                        "cShowCaption": "难度",
                        "iBillEntityId": 3940,
                        "iBillTplGroupId": 12353,
                        "iTplId": 3153,
                        "iMaxLength": 11,
                        "iFieldType": 1,
                        "bEnum": false,
                        "bMustSelect": true,
                        "bHidden": false,
                        "bExtend": false,
                        "iNumPoint": 2,
                        "bCanModify": true,
                        "iColWidth": 1,
                        "bShowIt": true,
                        "bFilter": true,
                        "bIsNull": true,
                        "bSelfDefine": false,
                        "cTplGroupName": "卡片",
                        "bMain": true,
                        "cDataSourceName": "AX001226.AX001226.lh_0319042",
                        "cControlType": "inputnumber",
                        "bVmExclude": 0,
                        "iOrder": 20,
                        "isshoprelated": false,
                        "iSystem": 1,
                        "authLevel": 3,
                        "isExport": true,
                        "uncopyable": false,
                        "bEnableFormat": false
                    },
                    "enable": {
                        "cFieldName": "enable",
                        "cItemName": "enable",
                        "cCaption": "启用",
                        "cShowCaption": "启用",
                        "iBillEntityId": 3940,
                        "iBillTplGroupId": 12353,
                        "iTplId": 3153,
                        "iMaxLength": 5,
                        "iFieldType": 1,
                        "bEnum": false,
                        "bMustSelect": true,
                        "bHidden": false,
                        "bExtend": false,
                        "bCanModify": true,
                        "iColWidth": 1,
                        "bShowIt": true,
                        "bFilter": true,
                        "bIsNull": true,
                        "bSelfDefine": false,
                        "cTplGroupName": "卡片",
                        "bMain": true,
                        "cDataSourceName": "AX001226.AX001226.lh_0319042",
                        "cControlType": "switch",
                        "bVmExclude": 0,
                        "iOrder": 30,
                        "isshoprelated": false,
                        "iSystem": 1,
                        "authLevel": 3,
                        "isExport": true,
                        "uncopyable": false,
                        "bEnableFormat": false
                    },
                    "name": {
                        "cFieldName": "name",
                        "cItemName": "name",
                        "cCaption": "名称",
                        "cShowCaption": "名称",
                        "iBillEntityId": 3940,
                        "iBillTplGroupId": 12353,
                        "iTplId": 3153,
                        "iMaxLength": 200,
                        "iFieldType": 1,
                        "bEnum": false,
                        "bMustSelect": true,
                        "bHidden": false,
                        "bExtend": false,
                        "bCanModify": true,
                        "iColWidth": 1,
                        "bShowIt": true,
                        "bFilter": true,
                        "bIsNull": true,
                        "bSelfDefine": false,
                        "cTplGroupName": "卡片",
                        "bMain": true,
                        "cDataSourceName": "AX001226.AX001226.lh_0319042",
                        "cControlType": "input",
                        "bVmExclude": 0,
                        "iOrder": 40,
                        "isshoprelated": false,
                        "iSystem": 1,
                        "authLevel": 3,
                        "isExport": true,
                        "uncopyable": false,
                        "bEnableFormat": false
                    },
                    "describe": {
                        "cFieldName": "describe",
                        "cItemName": "describe",
                        "cCaption": "描述信息",
                        "cShowCaption": "描述信息",
                        "iBillEntityId": 3940,
                        "iBillTplGroupId": 12353,
                        "iTplId": 3153,
                        "iMaxLength": 255,
                        "iFieldType": 1,
                        "bEnum": false,
                        "bMustSelect": true,
                        "bHidden": false,
                        "bExtend": false,
                        "bCanModify": true,
                        "iColWidth": 1,
                        "bShowIt": true,
                        "bFilter": true,
                        "bIsNull": true,
                        "bSelfDefine": false,
                        "cTplGroupName": "卡片",
                        "bMain": true,
                        "cDataSourceName": "AX001226.AX001226.lh_0319042",
                        "cControlType": "textarea",
                        "bVmExclude": 0,
                        "iOrder": 50,
                        "isshoprelated": false,
                        "iSystem": 1,
                        "authLevel": 3,
                        "isExport": true,
                        "uncopyable": false,
                        "bEnableFormat": false
                    },
                    "id": {
                        "cFieldName": "id",
                        "cItemName": "id",
                        "cCaption": "ID",
                        "cShowCaption": "ID",
                        "iBillEntityId": 3940,
                        "iBillTplGroupId": 12353,
                        "iTplId": 3153,
                        "iMaxLength": 36,
                        "iFieldType": 1,
                        "bEnum": false,
                        "bMustSelect": true,
                        "bHidden": true,
                        "bExtend": false,
                        "bCanModify": true,
                        "iColWidth": 1,
                        "bShowIt": false,
                        "bFilter": true,
                        "bIsNull": true,
                        "bSelfDefine": false,
                        "cTplGroupName": "卡片",
                        "bMain": true,
                        "cDataSourceName": "AX001226.AX001226.lh_0319042",
                        "cControlType": "input",
                        "bVmExclude": 0,
                        "iOrder": 60,
                        "isshoprelated": false,
                        "iSystem": 1,
                        "authLevel": 3,
                        "isExport": true,
                        "uncopyable": false,
                        "bEnableFormat": false
                    },
                    "pubts": {
                        "cFieldName": "pubts",
                        "cItemName": "pubts",
                        "cCaption": "时间戳",
                        "cShowCaption": "时间戳",
                        "iBillEntityId": 3940,
                        "iBillTplGroupId": 12353,
                        "iTplId": 3153,
                        "iMaxLength": 255,
                        "iFieldType": 1,
                        "bEnum": false,
                        "bMustSelect": true,
                        "bHidden": true,
                        "bExtend": false,
                        "bCanModify": true,
                        "iColWidth": 1,
                        "bShowIt": false,
                        "bFilter": true,
                        "bIsNull": true,
                        "bSelfDefine": false,
                        "cTplGroupName": "卡片",
                        "bMain": true,
                        "cDataSourceName": "AX001226.AX001226.lh_0319042",
                        "cControlType": "datepicker",
                        "bVmExclude": 0,
                        "iOrder": 70,
                        "isshoprelated": false,
                        "iSystem": 1,
                        "authLevel": 3,
                        "isExport": true,
                        "uncopyable": false,
                        "bEnableFormat": false
                    }
                },
                "dataSourceMode": "remote",
                "showCheckBox": true,
                "showAggregates": false,
                "showRowNo": true
            }),


            'params': {
                "billNo": "8f66b9aeMobileList",
                "billType": "YYList",
                "filterId": "906",
                "hasDataSource": true
            },

        };
        this.setData(fields);
        this.setDirty(false);



        var billType = "yylist" || 'voucherlist';
        var biz;
        if (billType == 'editvoucherlist' || billType == 'edittreevoucherlist') {
            biz = cb.biz.common['editvoucherlist'];
        } else {
            biz = cb.biz.common.voucherlist;
        }


        //common events start
        //actions

        _this.allActions = [{
            "cCommand": "btnSaveAndAdd",
            "cAction": "saveandadd",
            "cSvcUrl": "/bill/save",
            "cHttpMethod": "POST",
            "cParameter": "{\"isWeb\":\"false\"}"
        }, {
            "cCommand": "btnSave",
            "cAction": "save",
            "cSvcUrl": "/bill/save",
            "cHttpMethod": "POST",
            "cParameter": "{\"isWeb\":\"false\"}"
        }, {
            "cCommand": "btnAbandon",
            "cAction": "newback"
        }, {
            "cCommand": "scan",
            "cAction": "scan"
        }, {
            "cCommand": "back",
            "cAction": "newback"
        }, {
            "cCommand": "btnAdd",
            "cAction": "newadd"
        }];




        _this.get('btnAdd').on('click', function(params) {
            var args = cb.utils.extend(true, {}, {
                "cCommand": "cmdAdd",
                "cAction": "newadd",
                "cItemName": "btnAdd",
                "cCaption": "新建",
                "cShowCaption": "新建",
                "bEnum": false,
                "cControlType": "primarybutton",
                "iStyle": 0,
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "50983",
                "needClear": false
            }, {
                key: 'btnAdd'
            }, {
                params: params
            });
            args.cShowCaption = this._get_data('cShowCaption');
            args.cCaption = this._get_data('cCaption');

            biz.do('newadd', _this, args)
        });



        //check



        _this.on('columnSetting', function(params) {
            biz.do('columnSetting', _this, params);
        });
        //common events end

        if (billType == 'editvoucherlist') {
            var girdModelKeys = ["ax001226_ax001226_lh_0319042_15846325299171"]
            if (girdModelKeys) {
                girdModelKeys.forEach(function(key) {
                    var gridModel = _this.get(key);
                    if (gridModel) {
                        gridModel.on('afterCellValueChange', function(params) {
                            if (params) params.childrenField = key;
                            biz.do('cellCheck', _this, params);
                        })
                    }
                })
            }
        }

        _this.on('toggle', function(params) {
            biz.do('toggle', _this, params);
        });
        //注册
        _this.on('filterClick', function(params) {
            biz.do('search', _this, params);
        });



        this.biz = biz;
        // this.initData();
    };
    model.prototype.initData = function() {
        // if(cb.biz['AX001226'] && cb.biz['AX001226']['AX001226_8f66b9aeMobileList_VM_Extend']){
        //   console.info('%c AX001226_8f66b9aeMobileList_VM_Extend extendjs doAction', 'color:green');
        //   cb.biz['AX001226']['AX001226_8f66b9aeMobileList_VM_Extend'].doAction("init", this);
        // }else{
        //   console.log('%c no extend js' , 'font-size:22pt;color:red');
        // }
        var self = this;
        var extendFile = 'AX001226/AX001226_8f66b9aeMobileList_VM.Extend.js';
        cb.require([extendFile], function(extend) {
            if (extend && extend.doAction) {
                console.info('%c AX001226_8f66b9aeMobileList_VM_Extend extendjs doAction', 'color:green');
                // 处理扩展脚本异常导致渲染失败 yueming
                try {
                    extend.doAction("init", self);
                } catch (error) {
                    console.error('Exception in business script, please check');
                    console.error(error);
                }
            } else {
                console.error('%c 语法错误  ' + extendFile, 'font-size:12pt;color:#860786');
                console.error('%c extendVmName-->AX001226_8f66b9aeMobileList_VM_Extend', 'font-size:12pt;color:#860786')
            }
            self.execute('extendReady', self);
        }, function(error) {
            console.info('%c 未找到  ' + extendFile, 'font-size:12pt;color:#860786');
            console.info('%c extendVmName-->AX001226_8f66b9aeMobileList_VM_Extend', 'font-size:12pt;color:#860786')
            self.execute('extendReady', self);
        });
    };

    return model;
});