
const PortalComponents = {
}

export default PortalComponents
