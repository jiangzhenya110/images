import React, { useEffect, useState } from "react";
import Icon from 'antd-mobile/lib/icon'
import  'antd-mobile/lib/icon/style'
import Carousel from "antd-mobile/lib/carousel";
import "antd-mobile/lib/carousel/style/css";
import { connect } from "react-redux";
import { getPlatform } from "../../actions/utils";
import { useHistory } from "react-router-dom";
import Toast from 'antd-mobile/lib/toast'
import 'antd-mobile/lib/toast/style/index.css'
// import axios from 'axios'
import "./index.less";
import { initApps, tenantChange } from "../../actions/appsAction";
import { SyncOutlined } from '@ant-design/icons';

const Work = ({
  initApps,
  appsList,
  // tenantId,
  tenantList,
  tenantChange,
  tenantName,
  // loginMessObj,
}) => {
  const history = useHistory();
  const [selectShow, setSelectShow] = useState(false);
  const [spinF,setSpinF] = useState(false)
  const [bannerData, setBannerData] = useState({});

  useEffect(() => {
    if(!appsList.length) {
      initApps(history);
    }
    /**
     * 获取banner图列表信息
     * @author rongqb@yonyou.com
     * @date 20201022
     */
    mtl.getBannerList({
      url: window.localStorage.getItem('evnurl'),
      success: function(res) {
        setBannerData(res);
        console.log('bannerData: ', bannerData);
      }
    });
  }, []);

  const selectHandle = (bool) => {
    setSelectShow(bool);
  };
  const selectAction = (item) => {
    // console.log(item);
    tenantChange( item.tenantName, {
      terminalType: getPlatform(),tenantId:item.tenantId,
    },history)
  };
  const goToHomePage = (data) => {
    const wb_at = window.localStorage.getItem( 'wb_at' );
    const tenantId = window.localStorage.getItem('tenantId')
    const yhtToken = window.localStorage.getItem('yhtToken')
    // console.log(data)
    if (!data || data === '') {
      Toast.fail('此应用暂未部署', 1)
      return
    }
    mtl.getEsnCode({
      // url: 'https://yonbuilder.diwork.com',
      wb_at:wb_at,
      tenantId:tenantId,
      yht_access_token: yhtToken,
      success: function(res){
        Toast.hide()
        const esnCode = res.data
        const finalUrl = `${data}${/\?/.test(data)? '&': '?'}code=${esnCode}`
        if (esnCode && esnCode !== '') {
          window.location.href = finalUrl

        } else {
          Toast.fail('获取esnCode失败', 1)
        }
      },fail: function(err) {
        Toast.hide()
        Toast.fail(err.message, 1)
      }
    })
    // window.location.href=data
  }
  const reloadHandle = () => {
    setSpinF(true)
    initApps( history);
    setTimeout(() => {
      setSpinF(false)
    },1000)
  }

  // console.log(tenantList)
  return (
    <div className={"work-box"}>
      <div className={"work-tend"}>
        <span onClick={() => selectHandle(true)} className={"work-tend-name"}>
          <span className={'work-tend-name-t'}>{tenantName}</span>

        </span>
        {selectShow ? (
          <div
            onClick={() => selectHandle(false)}
            className={"work-tend-select"}
          >
            <ul className={"select-box"}>
              {/* <li onClick={selectAction}>1</li> */}
              {tenantList.map((item) => {
                return (
                  <li onClick={() => selectAction(item)}>
                    {item.tenantName}
                  </li>
                );
              })}
            </ul>
          </div>
        ) : null}
      </div>
      <div className="work-title"><span>应用名称</span></div>
        { bannerData.enable === true &&
          bannerData?.images?.length > 0 &&
          <div className="work-banner">
            <Carousel
              autoplay={true}
              autoplayInterval={bannerData.interval}
              infinite
              >
                {
                  bannerData?.images?.map(({src, type, href} = {}) => <div
                      onClick={() => {
                        if(typeof href == 'string'
                          && href
                          && type != 'none') {
                          goToHomePage(href);
                        }
                      }}
                      className="banner-top-item"
                      style={{
                        backgroundImage: `url(${src})`
                      }}
                    >
                  </div>)
                }
              </Carousel>
          </div>
        }
      <div className="work-main">
        <div className="work-main-w"><span>所构建应用</span><SyncOutlined onClick={reloadHandle} spin={spinF} /></div>
        {/* <div> */}
        <Carousel
          autoplay={false}
          infinite
        >
          {appsList.length ? (
            appsList.map((item) => {
              return (
                <div key={item[0].serviceId} className="work-main-c">
                  {item.map((inItem) => {
                    return (
                      <div onClick={()=>goToHomePage(inItem[getPlatform()].homepage)} key={inItem.serviceId} className="work-m-item">
                        <dl>
                          <dt>
                            <img src={inItem.serviceIcon} />
                          </dt>
                          <dd>{inItem.serviceName}</dd>
                        </dl>
                      </div>
                    );
                  })}
                </div>
              );
            })
          ) : (
              <div className="work-main-c-none">
                <dl className={'none-icon'}><dt></dt><dd>暂无应用</dd></dl>
            </div>
          )}
          {/* <div className="work-main-c">
              <div className="work-m-item">
                <dl>
                  <dt></dt>
                  <dd>listsssssss</dd>
                </dl>
              </div>
            </div>*/}
        </Carousel>
        {/* </div> */}
      </div>
    </div>
  );
};
// export default (Work);
export default connect(
  (state) => {
    return {
      tenantId: state.loginMessage.tenantId,
      tenantName: state.loginMessage.tenantName,
      tenantList: state.loginMessage.tenantList,
      appsList: [...state.appsMessage.appList],
      pagesList: state.appsMessage.pagesList,
      loginMessObj: {
        access_token: state.loginMessage.access_token,
        userId: state.loginMessage.userId,
        tenantId: state.loginMessage.tenantId,
      },
    };
  },
  {
    initApps: initApps,
    // pageChage,
    tenantChange
  }
)(Work);
