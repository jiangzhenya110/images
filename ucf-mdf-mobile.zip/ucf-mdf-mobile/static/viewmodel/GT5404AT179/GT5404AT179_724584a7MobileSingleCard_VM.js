//yyarchive

console.info('%c GT5404AT179_724584a7MobileSingleCard_VM js init', 'color:green');
cb.viewmodels.register('GT5404AT179_724584a7MobileSingleCard_VM', function(modelType) {

    var model = function(data) {
        cb.models.ContainerModel.call(this, data);
        this.init();
    };
    model.prototype = cb.utils.getPrototype(cb.models.ContainerModel.prototype);
    model.prototype.modelType = modelType;

    model.prototype.init = function() {
        var _this = this;
        var fields = {


            'wenben': new cb.models.SimpleModel({
                "cFieldName": "wenben",
                "cItemName": "wenben",
                "cCaption": "文本",
                "cShowCaption": "文本",
                "iBillEntityId": 40827,
                "iBillTplGroupId": 255279,
                "iTplId": 30462,
                "iMaxLength": 200,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bSplit": false,
                "bExtend": false,
                "iNumPoint": 2,
                "bCanModify": true,
                "iMaxShowLen": 200,
                "iColWidth": 1,
                "bNeedSum": false,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bPrintCaption": true,
                "bJointQuery": false,
                "bPrintUpCase": false,
                "bSelfDefine": false,
                "cTplGroupName": "Flex布局",
                "bMain": true,
                "cDataSourceName": "GT5404AT179.GT5404AT179.wenbelchax",
                "cControlType": "Input",
                "bVmExclude": 0,
                "iOrder": 0,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "iAlign": 1,
                "bEnableFormat": false
            }),


            'dawenben': new cb.models.SimpleModel({
                "cFieldName": "dawenben",
                "cItemName": "dawenben",
                "cCaption": "大文本",
                "cShowCaption": "大文本",
                "iBillEntityId": 40827,
                "iBillTplGroupId": 255279,
                "iTplId": 30462,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bSplit": false,
                "bExtend": false,
                "iNumPoint": 2,
                "bCanModify": true,
                "iColWidth": 1,
                "bNeedSum": false,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bPrintCaption": true,
                "bJointQuery": false,
                "bPrintUpCase": false,
                "bSelfDefine": false,
                "cTplGroupName": "Flex布局",
                "bMain": true,
                "cDataSourceName": "GT5404AT179.GT5404AT179.wenbelchax",
                "cControlType": "TextArea",
                "bVmExclude": 0,
                "iOrder": 1,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "iAlign": 1,
                "bEnableFormat": false
            }),


            'mActionList': new cb.models.SimpleModel({
                "cFieldName": "mActionList",
                "cItemName": "mActionList",
                "cCaption": "mActionList",
                "cShowCaption": "mActionList",
                "iBillEntityId": 40827,
                "iBillTplGroupId": 255282,
                "iTplId": 30462,
                "iMaxLength": 255,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bSplit": false,
                "bExtend": false,
                "bCanModify": true,
                "iMaxShowLen": 255,
                "bNeedSum": false,
                "bShowIt": false,
                "bFilter": true,
                "bIsNull": true,
                "bPrintCaption": true,
                "bJointQuery": false,
                "bPrintUpCase": false,
                "bSelfDefine": false,
                "cTplGroupName": "动作列表(勿动)",
                "bMain": true,
                "cControlType": "Button",
                "bVmExclude": 2,
                "iOrder": 1,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "iAlign": 1,
                "bEnableFormat": false
            }),


            'duoyuwenben': new cb.models.SimpleModel({
                "cFieldName": "duoyuwenben",
                "cItemName": "duoyuwenben",
                "cCaption": "多语文本",
                "cShowCaption": "多语文本",
                "iBillEntityId": 40827,
                "iBillTplGroupId": 255279,
                "iTplId": 30462,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bSplit": false,
                "bExtend": false,
                "iNumPoint": 2,
                "bCanModify": true,
                "iColWidth": 1,
                "bNeedSum": false,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bPrintCaption": true,
                "bJointQuery": false,
                "bPrintUpCase": false,
                "bSelfDefine": false,
                "cTplGroupName": "Flex布局",
                "bMain": true,
                "cDataSourceName": "GT5404AT179.GT5404AT179.wenbelchax",
                "cControlType": "InputMultiLang",
                "bVmExclude": 0,
                "iOrder": 2,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "iAlign": 1,
                "bEnableFormat": false
            }),


            'lianxifangshi': new cb.models.SimpleModel({
                "cFieldName": "lianxifangshi",
                "cItemName": "lianxifangshi",
                "cCaption": "联系方式",
                "cShowCaption": "联系方式",
                "iBillEntityId": 40827,
                "iBillTplGroupId": 255279,
                "iTplId": 30462,
                "iMaxLength": 50,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bSplit": false,
                "bExtend": false,
                "iNumPoint": 2,
                "bCanModify": true,
                "iMaxShowLen": 50,
                "iColWidth": 1,
                "bNeedSum": false,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bPrintCaption": true,
                "bJointQuery": false,
                "bPrintUpCase": false,
                "bSelfDefine": false,
                "cTplGroupName": "Flex布局",
                "bMain": true,
                "cDataSourceName": "GT5404AT179.GT5404AT179.wenbelchax",
                "cControlType": "Mobile",
                "bVmExclude": 0,
                "iOrder": 3,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "iAlign": 1,
                "bEnableFormat": false
            }),


            'zhengjianhao': new cb.models.SimpleModel({
                "cFieldName": "zhengjianhao",
                "cItemName": "zhengjianhao",
                "cCaption": "证件号",
                "cShowCaption": "证件号",
                "iBillEntityId": 40827,
                "iBillTplGroupId": 255279,
                "iTplId": 30462,
                "iMaxLength": 50,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": false,
                "bSplit": false,
                "bExtend": false,
                "iNumPoint": 2,
                "bCanModify": true,
                "iMaxShowLen": 50,
                "iColWidth": 1,
                "bNeedSum": false,
                "bShowIt": true,
                "bFilter": true,
                "bIsNull": true,
                "bPrintCaption": true,
                "bJointQuery": false,
                "bPrintUpCase": false,
                "bSelfDefine": false,
                "cTplGroupName": "Flex布局",
                "bMain": true,
                "cDataSourceName": "GT5404AT179.GT5404AT179.wenbelchax",
                "cControlType": "InputIdentity",
                "bVmExclude": 0,
                "iOrder": 4,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "iAlign": 1,
                "bEnableFormat": false
            }),


            'tenant_id': new cb.models.SimpleModel({
                "cFieldName": "tenant_id",
                "cItemName": "tenant_id",
                "cCaption": "租户id",
                "cShowCaption": "租户id",
                "iBillEntityId": 40827,
                "iBillTplGroupId": 255279,
                "iTplId": 30462,
                "iMaxLength": 256,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": true,
                "bSplit": false,
                "bExtend": false,
                "iNumPoint": 2,
                "bCanModify": true,
                "iMaxShowLen": 256,
                "iColWidth": 1,
                "bNeedSum": false,
                "bShowIt": false,
                "bFilter": true,
                "bIsNull": true,
                "bPrintCaption": true,
                "bJointQuery": false,
                "bPrintUpCase": false,
                "bSelfDefine": false,
                "cTplGroupName": "Flex布局",
                "bMain": true,
                "cDataSourceName": "GT5404AT179.GT5404AT179.wenbelchax",
                "cControlType": "Input",
                "bVmExclude": 0,
                "iOrder": 6,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "iAlign": 1,
                "bEnableFormat": false
            }),


            'id': new cb.models.SimpleModel({
                "cFieldName": "id",
                "cItemName": "id",
                "cCaption": "ID",
                "cShowCaption": "ID",
                "iBillEntityId": 40827,
                "iBillTplGroupId": 255279,
                "iTplId": 30462,
                "iMaxLength": 36,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": true,
                "bSplit": false,
                "bExtend": false,
                "iNumPoint": 2,
                "bCanModify": true,
                "iMaxShowLen": 36,
                "iColWidth": 1,
                "bNeedSum": false,
                "bShowIt": false,
                "bFilter": true,
                "bIsNull": true,
                "bPrintCaption": true,
                "bJointQuery": true,
                "bPrintUpCase": false,
                "bSelfDefine": false,
                "cTplGroupName": "Flex布局",
                "bMain": true,
                "cDataSourceName": "GT5404AT179.GT5404AT179.wenbelchax",
                "cControlType": "NumberWidget",
                "bVmExclude": 0,
                "iOrder": 11,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "iAlign": 1,
                "bEnableFormat": false,
                "subuitype": "int"
            }),


            'pubts': new cb.models.SimpleModel({
                "cFieldName": "pubts",
                "cItemName": "pubts",
                "cCaption": "时间戳",
                "cShowCaption": "时间戳",
                "iBillEntityId": 40827,
                "iBillTplGroupId": 255279,
                "iTplId": 30462,
                "iFieldType": 1,
                "bEnum": false,
                "bMustSelect": true,
                "bHidden": true,
                "bSplit": false,
                "bExtend": false,
                "iNumPoint": 2,
                "bCanModify": true,
                "iColWidth": 1,
                "bNeedSum": false,
                "bShowIt": false,
                "bFilter": true,
                "bIsNull": true,
                "bPrintCaption": true,
                "bJointQuery": false,
                "bPrintUpCase": false,
                "bSelfDefine": false,
                "cOrder": "desc",
                "cTplGroupName": "Flex布局",
                "bMain": true,
                "cDataSourceName": "GT5404AT179.GT5404AT179.wenbelchax",
                "cControlType": "DateTimePicker",
                "bVmExclude": 2,
                "iOrder": 12,
                "isshoprelated": false,
                "iSystem": 1,
                "authLevel": 3,
                "isExport": true,
                "uncopyable": false,
                "iAlign": 1,
                "bEnableFormat": false
            }),


            'btnEdit': new cb.models.SimpleModel({
                "cItemName": "btnEdit",
                "cCaption": "编辑",
                "cShowCaption": "编辑",
                "cControlType": "Button",
                "iStyle": 0,
                "cCommand": "cmdEdit",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436033",
                "needClear": false,
                "value": "编辑"
            }),


            'btnSubmit': new cb.models.SimpleModel({
                "cItemName": "btnSubmit",
                "cCaption": "提交",
                "cShowCaption": "提交",
                "cControlType": "Button",
                "iStyle": 0,
                "cCommand": "cmdSubmit",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436034",
                "needClear": false,
                "value": "提交"
            }),


            'approveflow': new cb.models.SimpleModel({
                "cItemName": "approveflow",
                "cCaption": "审批",
                "cShowCaption": "审批",
                "cControlType": "approveflow",
                "iStyle": 0,
                "cCommand": "cmdApproveFlow",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436035",
                "needClear": false,
                "value": "审批"
            }),


            'btnAbandon': new cb.models.SimpleModel({
                "cItemName": "btnAbandon",
                "cCaption": "取消",
                "cShowCaption": "取消",
                "cControlType": "Button",
                "iStyle": 0,
                "cCommand": "cmdAbandon",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436036",
                "needClear": false,
                "value": "取消"
            }),


            'btnSaveAndAdd': new cb.models.SimpleModel({
                "cItemName": "btnSaveAndAdd",
                "cCaption": "保存并新增",
                "cShowCaption": "保存并新增",
                "cControlType": "Button",
                "iStyle": 0,
                "cCommand": "cmdSaveAndAdd",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436037",
                "needClear": false,
                "value": "保存并新增"
            }),


            'btnSave': new cb.models.SimpleModel({
                "cItemName": "btnSave",
                "cCaption": "保存",
                "cShowCaption": "保存",
                "cControlType": "Button",
                "iStyle": 0,
                "cCommand": "cmdSave",
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436038",
                "needClear": false,
                "value": "保存"
            }),


            'params': {
                "billType": "YYArchive",
                "primaryKey": "id",
                "masterOrgField": null
            },


            'depends': {},

        };
        this.setData(fields);
        this.setDirty(false);



        var billType = "yyarchive" || 'yyarchive';
        var biz;
        if (billType == 'option' || billType == 'freeview') {
            biz = cb.biz.common[billType];
        } else {
            biz = cb.biz.common.yyarchive;
        }


        //common events start
        //actions

        _this.allActions = [{
            "cCommand": "cmdAbandon",
            "cAction": "abandon",
            "cSvcUrl": "/bill/abandon",
            "cHttpMethod": "GET",
            "title": "取消"
        }, {
            "cCommand": "cmdSubmit",
            "cAction": "submit",
            "cSvcUrl": "/bill/submit",
            "cHttpMethod": "POST",
            "title": "提交"
        }, {
            "cCommand": "cmdEdit",
            "cAction": "edit",
            "cSvcUrl": "/bill/edit",
            "cHttpMethod": "GET",
            "title": "编辑"
        }, {
            "cCommand": "cmdSave",
            "cAction": "save",
            "cSvcUrl": "/bill/save",
            "cHttpMethod": "POST",
            "title": "保存"
        }, {
            "cCommand": "cmdDeleteRow",
            "cAction": "deleteRow",
            "cSvcUrl": "/bill/deleteRow",
            "cHttpMethod": "GET",
            "title": "删行"
        }, {
            "cCommand": "cmdSaveAndAdd",
            "cAction": "saveandadd",
            "cSvcUrl": "/bill/save",
            "cHttpMethod": "POST",
            "title": "保存并新增"
        }, {
            "cCommand": "cmdAddRow",
            "cAction": "addrow"
        }];




        _this.get('btnAbandon').on('click', function(params) {
            var args = cb.utils.extend(true, {}, {
                "cCommand": "cmdAbandon",
                "cAction": "abandon",
                "cSvcUrl": "/bill/abandon",
                "cHttpMethod": "GET",
                "title": "取消",
                "cItemName": "btnAbandon",
                "cCaption": "取消",
                "cShowCaption": "取消",
                "cControlType": "Button",
                "iStyle": 0,
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436036",
                "needClear": false,
                "value": "取消"
            }, {
                key: 'btnAbandon'
            }, {
                params: params
            });
            args.cShowCaption = this._get_data('cShowCaption');
            args.cCaption = this._get_data('cCaption');

            var self = this;
            args.disabledCallback = function() {
                self.setDisabled(true);
            }
            args.enabledCallback = function() {
                self.setDisabled(false);
            }

            biz.do('abandon', _this, args)
        });


        _this.get('btnSubmit').on('click', function(params) {
            var args = cb.utils.extend(true, {}, {
                "cCommand": "cmdSubmit",
                "cAction": "submit",
                "cSvcUrl": "/bill/submit",
                "cHttpMethod": "POST",
                "title": "提交",
                "cItemName": "btnSubmit",
                "cCaption": "提交",
                "cShowCaption": "提交",
                "cControlType": "Button",
                "iStyle": 0,
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436034",
                "needClear": false,
                "value": "提交"
            }, {
                key: 'btnSubmit'
            }, {
                params: params
            });
            args.cShowCaption = this._get_data('cShowCaption');
            args.cCaption = this._get_data('cCaption');

            var self = this;
            args.disabledCallback = function() {
                self.setDisabled(true);
            }
            args.enabledCallback = function() {
                self.setDisabled(false);
            }

            biz.do('submit', _this, args)
        });


        _this.get('btnEdit').on('click', function(params) {
            var args = cb.utils.extend(true, {}, {
                "cCommand": "cmdEdit",
                "cAction": "edit",
                "cSvcUrl": "/bill/edit",
                "cHttpMethod": "GET",
                "title": "编辑",
                "cItemName": "btnEdit",
                "cCaption": "编辑",
                "cShowCaption": "编辑",
                "cControlType": "Button",
                "iStyle": 0,
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436033",
                "needClear": false,
                "value": "编辑"
            }, {
                key: 'btnEdit'
            }, {
                params: params
            });
            args.cShowCaption = this._get_data('cShowCaption');
            args.cCaption = this._get_data('cCaption');

            var self = this;
            args.disabledCallback = function() {
                self.setDisabled(true);
            }
            args.enabledCallback = function() {
                self.setDisabled(false);
            }

            biz.do('edit', _this, args)
        });


        _this.get('btnSave').on('click', function(params) {
            var args = cb.utils.extend(true, {}, {
                "cCommand": "cmdSave",
                "cAction": "save",
                "cSvcUrl": "/bill/save",
                "cHttpMethod": "POST",
                "title": "保存",
                "cItemName": "btnSave",
                "cCaption": "保存",
                "cShowCaption": "保存",
                "cControlType": "Button",
                "iStyle": 0,
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436038",
                "needClear": false,
                "value": "保存"
            }, {
                key: 'btnSave'
            }, {
                params: params
            });
            args.cShowCaption = this._get_data('cShowCaption');
            args.cCaption = this._get_data('cCaption');

            var self = this;
            args.disabledCallback = function() {
                self.setDisabled(true);
            }
            args.enabledCallback = function() {
                self.setDisabled(false);
            }

            biz.do('save', _this, args)
        });


        _this.get('btnSaveAndAdd').on('click', function(params) {
            var args = cb.utils.extend(true, {}, {
                "cCommand": "cmdSaveAndAdd",
                "cAction": "saveandadd",
                "cSvcUrl": "/bill/save",
                "cHttpMethod": "POST",
                "title": "保存并新增",
                "cItemName": "btnSaveAndAdd",
                "cCaption": "保存并新增",
                "cShowCaption": "保存并新增",
                "cControlType": "Button",
                "iStyle": 0,
                "bVmExclude": 0,
                "iOrder": 0,
                "uncopyable": false,
                "bEnableFormat": false,
                "key": "436037",
                "needClear": false,
                "value": "保存并新增"
            }, {
                key: 'btnSaveAndAdd'
            }, {
                params: params
            });
            args.cShowCaption = this._get_data('cShowCaption');
            args.cCaption = this._get_data('cCaption');

            var self = this;
            args.disabledCallback = function() {
                self.setDisabled(true);
            }
            args.enabledCallback = function() {
                self.setDisabled(false);
            }

            biz.do('saveandadd', _this, args)
        });



        //check



        _this.on('columnSetting', function(params) {
            biz.do('columnSetting', _this, params);
        });
        //common events end


        // common billitem events start
        // events

        _this.allEvents = [];




        //common billitem events end


        var girdModelKeys = []
        if (girdModelKeys) {
            girdModelKeys.forEach(function(key) {
                var gridModel = _this.get(key);
                if (gridModel) {
                    gridModel.on('afterCellValueChange', function(params) {
                        if (params) params.childrenField = key;
                        biz.do('cellCheck', _this, params);
                    })

                    //sub events start
                    //subActions



                    //sub events end

                }
            })
        }

        //注册
        _this.on('filterClick', function(params) {
            biz.do('search', _this, params);
        });



        this.biz = biz;
        // this.initData();
    };
    model.prototype.initData = function() {
        // if(cb.biz['GT5404AT179'] && cb.biz['GT5404AT179']['GT5404AT179_724584a7MobileSingleCard_VM_Extend']){
        //   console.info('%c GT5404AT179_724584a7MobileSingleCard_VM_Extend extendjs doAction', 'color:green');
        //   cb.biz['GT5404AT179']['GT5404AT179_724584a7MobileSingleCard_VM_Extend'].doAction("init", this);
        // }else{
        //   console.log('%c no extend js' , 'font-size:22pt;color:red');
        // }
        var self = this;
        var extendFile = 'GT5404AT179/GT5404AT179_724584a7MobileSingleCard_VM.Extend.js';
        cb.require([extendFile], function(extend) {
            if (extend && extend.doAction) {
                console.info('%c GT5404AT179_724584a7MobileSingleCard_VM_Extend extendjs doAction', 'color:green');
                // 处理扩展脚本异常导致渲染失败 yueming
                try {
                    // 临时切换到lazyExecute
                    cb.models.BaseModel.prototype.lazyExecuteMode = true
                    extend.doAction("init", self);
                    // 再切换回来
                    cb.models.BaseModel.prototype.lazyExecuteMode = false
                } catch (error) {
                    console.error('Exception in business script, please check');
                    console.error(error);
                }
            } else {
                console.error('%c 语法错误  ' + extendFile, 'font-size:12pt;color:#860786');
                console.error('%c extendVmName-->GT5404AT179_724584a7MobileSingleCard_VM_Extend', 'font-size:12pt;color:#860786')
            }
            self.execute('extendReady', self);
        }, function(error) {
            console.info('%c 未找到  ' + extendFile, 'font-size:12pt;color:#860786');
            console.info('%c extendVmName-->GT5404AT179_724584a7MobileSingleCard_VM_Extend', 'font-size:12pt;color:#860786')
            self.execute('extendReady', self);
        });
    };

    return model;
});