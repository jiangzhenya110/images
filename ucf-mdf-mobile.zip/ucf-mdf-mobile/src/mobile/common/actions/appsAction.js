// import axios from 'axios'
import mtl from "mtl-js-sdk";
// import appCenter from "mtl-js-sdk/lib/plugins/appcenter";
import {arrTrans } from './utils'
// mtl.loadPlugin(appCenter);
// const dataUrl = '/hpapaas-passport-be/hpaapp/mobileAppInfos'
const PREFIX = process.env.__CLIENT__
  ? window._baseUrl || ""
  : process.env.PREFIX || "";
const CLIENT = process.env.__CLIENT__;
let DOMAIN_PREFIX = CLIENT ? window._baseUrl || "" : PREFIX || "";
if (DOMAIN_PREFIX === undefined) {
  DOMAIN_PREFIX = "";
}
export const APPS_INIT = "APPS_INIT";
export const APPS_PAGE = "APPS_PAGE";
export const TENANT_CHANGE = 'TENANT_CHANGE'
export const RESET = 'RESET'
export const reSetAction = () => ({type:RESET})
export const initApps = (history) => (dispatch) => {
  // console.log('1111')
  if (!window.localStorage.getItem('mtlLoginInfo') &&!window.localStorage.getItem('userId') &&!window.localStorage.getItem('tenantId')) {
    history.replace(`${DOMAIN_PREFIX}/workbench/login`);
  }
  mtl.getAppList({
    url: window.localStorage.getItem('evnurl'),
    success: function (res) {
      // console.log(res)
      let appsList = [];
      for (let i = 0; i < res.data.length; i++) {
        // console.log(res.data[i].children)
        if (res.data[i].children && res.data[i].children.length) {
          appsList.push.apply(appsList, res.data[i].children);
        }
      }
      // console.log(appsList);
      // appsList = arrTrans(20,appsList)
      window.localStorage.setItem('appsList',JSON.stringify(appsList))
      dispatch({
        type: APPS_INIT,
        payload: {
          total:appsList.length,
          list:arrTrans(20,appsList)
        }

        // payload: arrTrans(20,appsList)
      });
    },
    fail (res) {
      console.log(res)
      history.replace(`${DOMAIN_PREFIX}/workbench/login`);
    }
  })
  return
};

export const tenantChange = (tenantName, getAppObj, history) => dispatch => {
  mtl.changeTenant({
    url: window.localStorage.getItem('evnurl'),
    tenantId:getAppObj.tenantId,
    success:function (res) {
      // console.log(res)
      window.localStorage.setItem("tenantId", getAppObj.tenantId);
  window.localStorage.setItem("tenantName", tenantName);
  dispatch({
    type: TENANT_CHANGE,
    payload: {
      tenantId:getAppObj.tenantId,
      tenantName
    }
  })
  dispatch(initApps(history))
    },
    fail:function (err) {
      // Toast.fail(err.message, 1)
    }
  })
}

